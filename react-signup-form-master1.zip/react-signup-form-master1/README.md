# react-signup-form

Demo http://codepen.io/mikepro4/full/pvKYZG/

1. ```npm install```
2. ```npm start``` – will create ```/build``` directory
3. Go to ```/build``` directory and type ```python -m SimpleHTTPServer```
4. Go to ```localhost:8000```

Will be watching LESS and JS files and compiling them into ```/build```.

For deploying to production:
```NODE_ENV=production gulp deploy``` – will create ```/dist``` directory with compiled and minified single javascript file
