# Create a Dynamic, Modern Sidebar in React using Recursion

[https://medium.com/better-programming/create-a-modern-dynamic-sidebar-menu-in-react-using-recursion-f757135045bc](https://medium.com/better-programming/create-a-modern-dynamic-sidebar-menu-in-react-using-recursion-f757135045bc)

[https://jsmanifest.com/create-a-modern-dynamic-sidebar-in-react-using-recursion/](https://jsmanifest.com/create-a-modern-dynamic-sidebar-in-react-using-recursion/)
